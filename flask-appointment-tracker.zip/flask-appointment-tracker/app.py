"""
Appointment Tracker - Flask & MySQL Web Application
Main application file with all routes for managing medical appointments.
"""

from flask import Flask, render_template, request, redirect, url_for, flash
import mysql.connector
from mysql.connector import Error
from datetime import datetime

app = Flask(__name__)
app.secret_key = "change-this-to-a-secure-random-string"


# ---------------------------------------------------------------------------
# Database Connection
# ---------------------------------------------------------------------------
def get_db_connection():
    """
    Establish and return a MySQL database connection.
    Update the credentials below to match your local MySQL setup.
    """
    try:
        connection = mysql.connector.connect(
            host="localhost",
            user="root",
            password="Melodybell00$",
            database="appointment_tracker",
        )
        return connection
    except Error as e:
        print(f"[DB ERROR] Could not connect to MySQL: {e}")
        return None


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------
@app.route("/")
def home():
    """Landing page with a quick summary of features."""
    stats = {"total": 0, "scheduled": 0, "completed": 0, "cancelled": 0}
    conn = get_db_connection()
    if conn:
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT COUNT(*) FROM appointments")
            stats["total"] = cursor.fetchone()[0]
            cursor.execute(
                "SELECT status, COUNT(*) FROM appointments GROUP BY status"
            )
            for status, count in cursor.fetchall():
                stats[status.lower()] = count
            cursor.close()
        except Error as e:
            print(f"[DB ERROR] {e}")
        finally:
            conn.close()
    return render_template("home.html", stats=stats)


@app.route("/appointments")
def appointments():
    """Display all appointments in a table."""
    appointments_list = []
    conn = get_db_connection()
    if conn:
        try:
            cursor = conn.cursor(dictionary=True)
            cursor.execute(
                "SELECT * FROM appointments "
                "ORDER BY appointment_date DESC, appointment_time DESC"
            )
            appointments_list = cursor.fetchall()
            cursor.close()
        except Error as e:
            flash(f"Database error: {e}", "danger")
        finally:
            conn.close()
    else:
        flash("Could not connect to the database.", "danger")

    return render_template("appointments.html", appointments=appointments_list)


@app.route("/add", methods=["GET", "POST"])
def add_appointment():
    """Add a new appointment via form submission."""
    if request.method == "POST":
        patient_name = request.form.get("patient_name", "").strip()
        doctor_name = request.form.get("doctor_name", "").strip()
        appointment_date = request.form.get("appointment_date", "").strip()
        appointment_time = request.form.get("appointment_time", "").strip()
        reason = request.form.get("reason", "").strip()
        status = request.form.get("status", "Scheduled").strip()

        # Basic validation
        if not all([patient_name, doctor_name, appointment_date, appointment_time]):
            flash("Please fill in all required fields.", "warning")
            return render_template("add.html", form=request.form)

        conn = get_db_connection()
        if conn:
            try:
                cursor = conn.cursor()
                cursor.execute(
                    """
                    INSERT INTO appointments
                        (patient_name, doctor_name, appointment_date,
                         appointment_time, reason, status)
                    VALUES (%s, %s, %s, %s, %s, %s)
                    """,
                    (
                        patient_name,
                        doctor_name,
                        appointment_date,
                        appointment_time,
                        reason,
                        status,
                    ),
                )
                conn.commit()
                cursor.close()
                flash("Appointment added successfully!", "success")
                return redirect(url_for("appointments"))
            except Error as e:
                flash(f"Database error: {e}", "danger")
            finally:
                conn.close()
        else:
            flash("Could not connect to the database.", "danger")

    return render_template("add.html", form={})


@app.route("/update/<int:appointment_id>", methods=["GET", "POST"])
def update_appointment(appointment_id):
    """Update an existing appointment."""
    conn = get_db_connection()
    if not conn:
        flash("Could not connect to the database.", "danger")
        return redirect(url_for("appointments"))

    try:
        cursor = conn.cursor(dictionary=True)

        if request.method == "POST":
            patient_name = request.form.get("patient_name", "").strip()
            doctor_name = request.form.get("doctor_name", "").strip()
            appointment_date = request.form.get("appointment_date", "").strip()
            appointment_time = request.form.get("appointment_time", "").strip()
            reason = request.form.get("reason", "").strip()
            status = request.form.get("status", "Scheduled").strip()

            if not all(
                [patient_name, doctor_name, appointment_date, appointment_time]
            ):
                flash("Please fill in all required fields.", "warning")
            else:
                cursor.execute(
                    """
                    UPDATE appointments
                    SET patient_name = %s,
                        doctor_name = %s,
                        appointment_date = %s,
                        appointment_time = %s,
                        reason = %s,
                        status = %s
                    WHERE id = %s
                    """,
                    (
                        patient_name,
                        doctor_name,
                        appointment_date,
                        appointment_time,
                        reason,
                        status,
                        appointment_id,
                    ),
                )
                conn.commit()
                flash("Appointment updated successfully!", "success")
                return redirect(url_for("appointments"))

        # GET request: fetch the existing record to pre-fill the form
        cursor.execute(
            "SELECT * FROM appointments WHERE id = %s", (appointment_id,)
        )
        appointment = cursor.fetchone()
        cursor.close()

        if not appointment:
            flash("Appointment not found.", "warning")
            return redirect(url_for("appointments"))

        return render_template("update.html", appointment=appointment)
    except Error as e:
        flash(f"Database error: {e}", "danger")
        return redirect(url_for("appointments"))
    finally:
        conn.close()


@app.route("/delete/<int:appointment_id>", methods=["POST"])
def delete_appointment(appointment_id):
    """Delete an appointment by ID."""
    conn = get_db_connection()
    if conn:
        try:
            cursor = conn.cursor()
            cursor.execute(
                "DELETE FROM appointments WHERE id = %s", (appointment_id,)
            )
            conn.commit()
            cursor.close()
            flash("Appointment deleted successfully.", "success")
        except Error as e:
            flash(f"Database error: {e}", "danger")
        finally:
            conn.close()
    else:
        flash("Could not connect to the database.", "danger")

    return redirect(url_for("appointments"))


@app.route("/search", methods=["GET", "POST"])
def search_appointments():
    """Search appointments by patient name, doctor name, or date."""
    results = []
    query = ""
    search_type = "patient_name"

    if request.method == "POST":
        query = request.form.get("query", "").strip()
        search_type = request.form.get("search_type", "patient_name")

        if query:
            conn = get_db_connection()
            if conn:
                try:
                    cursor = conn.cursor(dictionary=True)

                    if search_type == "appointment_date":
                        # Exact date match (YYYY-MM-DD)
                        cursor.execute(
                            "SELECT * FROM appointments "
                            "WHERE appointment_date = %s "
                            "ORDER BY appointment_time ASC",
                            (query,),
                        )
                    elif search_type in ("patient_name", "doctor_name"):
                        sql = (
                            f"SELECT * FROM appointments "
                            f"WHERE {search_type} LIKE %s "
                            f"ORDER BY appointment_date DESC, "
                            f"appointment_time DESC"
                        )
                        cursor.execute(sql, (f"%{query}%",))
                    else:
                        # Fallback: search across all three fields
                        cursor.execute(
                            """
                            SELECT * FROM appointments
                            WHERE patient_name LIKE %s
                               OR doctor_name LIKE %s
                            ORDER BY appointment_date DESC,
                                     appointment_time DESC
                            """,
                            (f"%{query}%", f"%{query}%"),
                        )

                    results = cursor.fetchall()
                    cursor.close()
                except Error as e:
                    flash(f"Database error: {e}", "danger")
                finally:
                    conn.close()
            else:
                flash("Could not connect to the database.", "danger")
        else:
            flash("Please enter a search query.", "warning")

    return render_template(
        "search.html", results=results, query=query, search_type=search_type
    )


# ---------------------------------------------------------------------------
# Template Filters
# ---------------------------------------------------------------------------
@app.template_filter("format_time")
def format_time(value):
    """Format a TIME or timedelta value for display (HH:MM)."""
    if value is None:
        return ""
    if hasattr(value, "total_seconds"):
        total = int(value.total_seconds())
        hours, remainder = divmod(total, 3600)
        minutes = remainder // 60
        return f"{hours:02d}:{minutes:02d}"
    if hasattr(value, "strftime"):
        return value.strftime("%H:%M")
    return str(value)


@app.template_filter("format_date")
def format_date(value):
    """Format a DATE value for display."""
    if value is None:
        return ""
    if hasattr(value, "strftime"):
        return value.strftime("%b %d, %Y")
    return str(value)


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    app.run(debug=True)
