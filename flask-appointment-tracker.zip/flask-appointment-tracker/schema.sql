-- =====================================================================
-- Appointment Tracker - Database Schema
-- =====================================================================
-- Run this file from a terminal:
--     mysql -u root -p < schema.sql
-- Or paste the contents into MySQL Workbench / phpMyAdmin and execute.
-- =====================================================================

-- Create the database (drop existing one to start fresh)
DROP DATABASE IF EXISTS appointment_tracker;
CREATE DATABASE appointment_tracker
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE appointment_tracker;

-- ---------------------------------------------------------------------
-- Table: appointments
-- ---------------------------------------------------------------------
CREATE TABLE appointments (
    id                INT             NOT NULL AUTO_INCREMENT,
    patient_name      VARCHAR(100)    NOT NULL,
    doctor_name       VARCHAR(100)    NOT NULL,
    appointment_date  DATE            NOT NULL,
    appointment_time  TIME            NOT NULL,
    reason            VARCHAR(255)    DEFAULT NULL,
    status            ENUM('Scheduled','Completed','Cancelled')
                                      NOT NULL DEFAULT 'Scheduled',
    created_at        TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    INDEX idx_patient (patient_name),
    INDEX idx_doctor (doctor_name),
    INDEX idx_date (appointment_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------------------------------------------------------------
-- Sample data (optional) - useful for testing the application
-- ---------------------------------------------------------------------
INSERT INTO appointments
    (patient_name, doctor_name, appointment_date, appointment_time, reason, status)
VALUES
    ('Alice Johnson', 'Dr. Smith',   '2026-05-20', '09:30:00', 'Annual physical exam',   'Scheduled'),
    ('Bob Williams',  'Dr. Patel',   '2026-05-21', '10:00:00', 'Follow-up consultation', 'Scheduled'),
    ('Carol Davis',   'Dr. Smith',   '2026-05-18', '14:15:00', 'Blood pressure check',   'Completed'),
    ('David Brown',   'Dr. Garcia',  '2026-05-22', '11:45:00', 'Allergy testing',        'Scheduled'),
    ('Emma Wilson',   'Dr. Chen',    '2026-05-15', '08:00:00', 'Dental cleaning',        'Cancelled'),
    ('Frank Miller',  'Dr. Patel',   '2026-05-25', '16:30:00', 'Lab results review',     'Scheduled'),
    ('Grace Lee',     'Dr. Garcia',  '2026-05-19', '13:00:00', 'Vaccination',            'Completed');

-- ---------------------------------------------------------------------
-- Verify the schema
-- ---------------------------------------------------------------------
-- DESCRIBE appointments;
-- SELECT * FROM appointments;
